import cron, { ScheduledTask } from "node-cron";
import { Telegraf } from "telegraf";
import { ShiftService } from "../services/shiftService";
import { AdminService } from "../services/adminService";
import { env } from "../config/env";
import { messages } from "../bot/messages";
import { formatTime } from "../utils/time";
import { logger } from "../config/logger";

export const runAutoCloseOnce = async (
  bot: Telegraf,
  shiftService: ShiftService,
  adminService: AdminService
): Promise<void> => {
  const results = await shiftService.autoCloseOverdueShifts(new Date());
  if (results.length === 0) {
    return;
  }

  const adminChatIds = await adminService.getAdminChatIds();

  for (const result of results) {
    const endTime = formatTime(result.endTime, env.timezone);
    const employeeName = result.shift.employee.displayName;

    const bossMessage = messages.autoClosedBoss(employeeName, endTime, env.maxShiftHours);
    for (const adminChatId of adminChatIds) {
      try {
        await bot.telegram.sendMessage(adminChatId, bossMessage);
      } catch (error) {
        logger.error({ err: error, adminChatId }, "Failed to notify admin about auto-close");
      }
    }

    if (env.notifyEmployeeOnAutoClose) {
      try {
        await bot.telegram.sendMessage(
          result.shift.employee.telegramUserId,
          messages.autoClosedEmployee(env.maxShiftHours)
        );
      } catch (error) {
        logger.error({ err: error, employeeId: result.shift.employee.telegramUserId }, "Failed to notify employee");
      }
    }
  }
};

export const scheduleAutoCloseJob = (
  bot: Telegraf,
  shiftService: ShiftService,
  adminService: AdminService
): ScheduledTask => {
  const task = cron.schedule(
    env.overdueCheckCron,
    async () => {
      try {
        await runAutoCloseOnce(bot, shiftService, adminService);
      } catch (error) {
        logger.error({ err: error }, "Auto-close job failed");
      }
    },
    {
      timezone: env.timezone
    }
  );

  task.start();
  return task;
};
