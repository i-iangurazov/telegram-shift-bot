import cron, { ScheduledTask } from "node-cron";
import { env } from "../config/env";
import { PendingActionService } from "../services/pendingActionService";
import { logger } from "../config/logger";

export const runPendingActionCleanupOnce = async (
  pendingActionService: PendingActionService,
  now: Date = new Date()
): Promise<void> => {
  const expired = await pendingActionService.expirePendingActions(now);
  if (expired > 0) {
    logger.info({ expired }, "Expired pending actions");
  }
};

export const schedulePendingActionCleanupJob = (
  pendingActionService: PendingActionService
): ScheduledTask => {
  const task = cron.schedule(
    env.pendingActionCleanupCron,
    async () => {
      try {
        await runPendingActionCleanupOnce(pendingActionService, new Date());
      } catch (error) {
        logger.error({ err: error }, "Pending action cleanup failed");
      }
    },
    { timezone: env.timezone }
  );

  task.start();
  return task;
};
