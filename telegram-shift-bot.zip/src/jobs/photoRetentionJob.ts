import cron, { ScheduledTask } from "node-cron";
import { env } from "../config/env";
import { ShiftRepository } from "../repositories/shiftRepository";
import { logger } from "../config/logger";

export const runPhotoRetentionCleanupOnce = async (
  shiftRepo: ShiftRepository,
  now: Date = new Date()
): Promise<void> => {
  const cutoff = new Date(now.getTime() - env.photoRetentionDays * 24 * 60 * 60 * 1000);
  const purged = await shiftRepo.purgeOldPhotos(cutoff, now);
  if (purged > 0) {
    logger.info({ purged }, "Purged old shift photos");
  }
};

export const schedulePhotoRetentionJob = (shiftRepo: ShiftRepository): ScheduledTask => {
  const task = cron.schedule(
    env.photoRetentionCron,
    async () => {
      try {
        await runPhotoRetentionCleanupOnce(shiftRepo, new Date());
      } catch (error) {
        logger.error({ err: error }, "Photo retention cleanup failed");
      }
    },
    { timezone: env.timezone }
  );

  task.start();
  return task;
};
